package net.sf.colorer.eclipse.outline;

/**
 * 
 */
public interface OutlineListener {
  void notifyUpdate();
}
